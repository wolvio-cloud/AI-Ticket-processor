"""
update_ticket.py - Update Zendesk tickets with AI analysis
"""
import os
import json
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

ZENDESK_SUBDOMAIN = os.getenv('ZENDESK_SUBDOMAIN')
ZENDESK_EMAIL = os.getenv('ZENDESK_EMAIL')
ZENDESK_API_TOKEN = os.getenv('ZENDESK_API_TOKEN')


def update_ticket(ticket_id, analysis):
    """
    Update Zendesk ticket with AI analysis results
    
    Args:
        ticket_id: Zendesk ticket ID
        analysis: Dictionary with analysis results
        
    Returns:
        Boolean indicating success
    """
    
    # Create internal comment with analysis
    internal_comment = f"""🤖 AI Analysis:

Summary: {analysis['summary']}
Root Cause: {analysis['root_cause']}
Urgency: {analysis['urgency']}
Sentiment: {analysis['sentiment']}
"""
    
    # Create tags
    tags = [
        "ai-processed",
        analysis['root_cause'],
        analysis['urgency'],
        analysis['sentiment']
    ]
    
    url = f"https://{ZENDESK_SUBDOMAIN}.zendesk.com/api/v2/tickets/{ticket_id}.json"
    
    payload = {
        "ticket": {
            "comment": {
                "body": internal_comment,
                "public": False  # Internal note, not visible to customer
            },
            "additional_tags": tags
        }
    }
    
    try:
        response = requests.put(
            url,
            json=payload,
            auth=(f"{ZENDESK_EMAIL}/token", ZENDESK_API_TOKEN),
            timeout=10
        )
        response.raise_for_status()
        
        print(f"✅ Ticket #{ticket_id} updated successfully")
        print(f"   Tags added: {', '.join(tags)}")
        return True
        
    except requests.exceptions.RequestException as e:
        print(f"❌ Error updating ticket #{ticket_id}: {str(e)}")
        return False


def update_ticket_batch(tickets_with_analysis):
    """
    Update multiple tickets at once
    
    Args:
        tickets_with_analysis: List of (ticket_id, analysis) tuples
        
    Returns:
        Dictionary with success/failure counts
    """
    results = {
        "success": 0,
        "failed": 0
    }
    
    for ticket_id, analysis in tickets_with_analysis:
        if update_ticket(ticket_id, analysis):
            results["success"] += 1
        else:
            results["failed"] += 1
    
    print(f"\n📊 Batch Update Results:")
    print(f"   ✅ Success: {results['success']}")
    print(f"   ❌ Failed: {results['failed']}")
    
    return results


if __name__ == "__main__":
    # Test with sample data
    print("🔧 Testing ticket update...\n")
    
    sample_analysis = {
        "summary": "Customer requesting refund for delayed order",
        "root_cause": "refund",
        "urgency": "high",
        "sentiment": "negative"
    }
    
    # You would replace this with an actual ticket ID
    test_ticket_id = input("Enter a test ticket ID (or press Enter to skip): ").strip()
    
    if test_ticket_id:
        update_ticket(int(test_ticket_id), sample_analysis)
    else:
        print("⏭️  Skipping update test")
